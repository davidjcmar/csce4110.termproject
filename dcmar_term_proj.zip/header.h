/*
Main Header
David Cmar
November, 2015
*/
#ifndef __header__
#define __header__

#include <iostream>
#include <fstream>
#include <cstdlib>
//#include <string>
//#include <sys/resource.h>
//#include <sys/times.h>
//#include <time.h>
#endif